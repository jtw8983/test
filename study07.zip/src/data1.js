export const list =  [
    {title: "아이템1", content: "내용", accept: 1},
    {title: "아이템2", content: "설명", accept: 2},

]