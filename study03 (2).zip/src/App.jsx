import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import { BrowserRouter, Routes, Route } from "react-router";
import List from "./pages/List.jsx"
import Select from "./pages/Select.jsx"
import Select1 from "./pages/Select1.jsx"
import Select2 from "./pages/Select2.jsx"
import Select3 from "./pages/Select3.jsx"
import Select4 from "./pages/Select4.jsx"
import Select5 from "./pages/Select5.jsx"
import List1 from "./pages/List1.jsx"
import List2 from "./pages/List2.jsx"
import List3 from "./pages/List3.jsx"
import List4 from "./pages/List4.jsx"
import List5 from "./pages/List5.jsx"
import List6 from "./pages/List6.jsx"
import Create from "./pages/Create.jsx"
import Createfull from "./pages/Createfull.jsx"
import Create1 from "./pages/Create1.jsx"
import Create2 from "./pages/Create2.jsx"
import Create3 from "./pages/Create3.jsx"
import Create4 from "./pages/Create4.jsx"
import Create5 from "./pages/Create5.jsx"
import Create6 from "./pages/Create6.jsx"


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<List />} />
        <Route path='/list1' element={<List1 />} />
        <Route path='/list2' element={<List2 />} />
        <Route path='/list3' element={<List3 />} />
        <Route path='/list4' element={<List4 />} />
        <Route path='/list5' element={<List5 />} />
        <Route path='/list6' element={<List6 />} />
        <Route path='/detail' element={<Select />} />
        <Route path='/detail1' element={<Select1 />} />
        <Route path='/detail2' element={<Select2 />} />
        <Route path='/detail3' element={<Select3 />} />
        <Route path='/detail4' element={<Select4 />} />
        <Route path='/detail5' element={<Select5 />} />
        <Route path='/new' element={<Create />} />
        <Route path='/newfull' element={<Createfull />} />
        <Route path='/new1' element={<Create1 />} />
        <Route path='/new2' element={<Create2 />} />
        <Route path='/new3' element={<Create3 />} />
        <Route path='/new4' element={<Create4 />} />
        <Route path='/new5' element={<Create5 />} />
        <Route path='/new6' element={<Create6 />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
