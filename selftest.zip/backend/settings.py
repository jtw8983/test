from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    
    mariadb_user: str
    mariadb_password: str
    mariadb_host: str
    mariadb_database: str
    mariadb_port: int

    # .env 파일을 읽어오도록 설정
    model_config = SettingsConfigDict(
    env_file=".env",
    env_file_encoding="utf-8",
  )

settings = Settings()