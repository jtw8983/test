import { useCookies } from 'react-cookie';
import { api } from '@utils/network.js';

const CookieTest = () => {
  const [cookies, setCookie, removeCookie] = useCookies(['boardNo', 'server_check']);

  // 프론트에서 쿠키 생성
  const createFrontCookie = () => {
    // 백엔드에서 base64Decode를 하므로, 값을 인코딩해서 넣는 것이 좋습니다.
    const encodedVal = window.btoa("1"); // "1"을 base64로 인코딩
    setCookie('boardNo', encodedVal, { path: '/' });
    alert("프론트 쿠키(boardNo) 생성 완료!");
  };

  // 백엔드와 연동 (숙제 3번)
  const callBackend = () => {
    api.post("/board")
      .then(res => alert("백엔드 응답: " + res.data.message))
      .catch(err => console.error(err));
  };

  return (
    <div className="container mt-5">
      <h3>쿠키 숙제 테스트</h3>
      <button onClick={createFrontCookie} className="btn btn-info me-2">1. 프론트 쿠키 생성</button>
      <button onClick={callBackend} className="btn btn-warning me-2">2. 백엔드 연동(쿠키 주고받기)</button>
      <button onClick={() => removeCookie('boardNo')} className="btn btn-danger">3. 프론트 쿠키 삭제</button>
      <hr />
      <p>현재 브라우저 쿠키(boardNo): {cookies.boardNo}</p>
      <p>서버가 준 쿠키(server_check): {cookies.server_check}</p>
    </div>
  );
};