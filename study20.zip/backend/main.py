from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from settings import settings
import urllib.parse
import base64

def base64Decode(data):
  encoded = urllib.parse.unquote(data)
  return base64.b64decode(encoded).decode("utf-8")

origins = [ settings.react_url, "http://localhost:5173",      # 도메인 이름 사용
    "http://127.0.0.1:5173", ]

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
  return { "status": True }

@app.post("/board")
def board(request: Request, response: Response):
    # 1. 프론트에서 보낸 쿠키 읽기 (request 사용)
    # 변수명을 하나로 통일합니다 (boardNo)
    boardNo_raw = request.cookies.get("boardNo")
    
    if boardNo_raw:
        print(f"받은 쿠키(인코딩됨): {boardNo_raw}")
        
        # 2. 백엔드에서 새로운 쿠키 구워주기 (response 사용) - 숙제 2단계 핵심
        response.set_cookie(
            key="server_check", 
            value="backend_confirmed", 
            max_age=3600, 
            httponly=True,
            samesite="lax" # CORS 환경에서 쿠키 전달을 돕습니다.
        )
        
        # 디코딩 로직 수행
        decoded_no = int(base64Decode(boardNo_raw))
        return {"status": "success", "boardNo": decoded_no, "message": "서버 쿠키 생성 완료!"}
    
    return {"status": False, "message": "쿠키가 없습니다."}

@app.get("/logout")
def logout(response: Response):
    # 3. 백엔드에서 쿠키 지우기 - 숙제 2단계 핵심
    response.delete_cookie(key="server_check")
    return {"message": "서버 측 쿠키가 삭제되었습니다."}
